package threads.listeners;

public interface Observer {
	
	public void notify(String msg);

}
