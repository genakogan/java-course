package chain;

public class Package {
	String value;

	public Package(String value) {
		this.value = value;
	}
	
	public String getValue() {return value;}

}
