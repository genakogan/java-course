
public class SingeltonPaternDemo {	
	public static void main(String[] args) {
	SingleObject obje=SingleObject.getIstanse();
	obje.showMessage();
	
	}
}
