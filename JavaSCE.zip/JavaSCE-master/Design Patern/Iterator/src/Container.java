public interface Container {
   public Iterator getIterator();
   public Object[] getRepository();
}