
public class DemoTest {
	public static void main(String[] args) {
		Animal a = new Animal (1, 1);
		Lion b = new Lion (3, 5);
		Animal c = new Lion (5, 6);
		
//		System.out.println(a.weight);
//		System.out.println(a.speed);
//		System.out.println(b.weight);
//		System.out.println(b.speed);
//		System.out.println(c.weight);
//		System.out.println(c.speed);
//		b.printWeight();
//		b.printSpeed();
//		c.printWeight();
//		c.printSpeed();

		}

}
