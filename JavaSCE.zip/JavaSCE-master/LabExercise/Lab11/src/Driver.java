
public class Driver {
	public static void main(String[] args) {

		HorseRace.getRaceInstance().prepareRace();
		HorseRace.getRaceInstance().startRace();

	}
}
