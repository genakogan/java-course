
public class VegBurger implements Item{

	@Override
	public String name() {
		return "Veg burger";
	}

	@Override
	public float price() {
		return 25.0f;
	}

}
