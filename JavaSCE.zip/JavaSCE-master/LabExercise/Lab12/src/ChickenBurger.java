public class ChickenBurger implements Item{
	@Override
	public String name() {
		return "Chicken Burger";
	}
	@Override
	public float price() {
		return 50.5f;
	}
}
